
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `calls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calls` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned DEFAULT NULL,
  `call_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caller_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_date` datetime DEFAULT NULL,
  `call_duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_talktime` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_disconnection` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calls` WRITE;
/*!40000 ALTER TABLE `calls` DISABLE KEYS */;
INSERT INTO `calls` VALUES (1,1,'255746805383','255746805383','2021-08-26 19:53:55','1342','13241234','12','12','12','2021-10-02 09:33:06','2021-10-02 09:33:06'),(2,2,'255746805383','255746805381','2021-08-26 19:53:55','13','8','success','123','doctor','2021-10-04 00:15:27','2021-10-04 00:15:27'),(3,4,'255746805383','255746805381','2021-08-26 19:53:55','13','8','success','123','doctor','2021-10-04 00:16:03','2021-10-04 00:16:03'),(4,1,'255746805383','255746805381','2021-08-26 19:53:55','13','8','success','123','doctor','2021-10-04 00:17:50','2021-10-04 00:17:50'),(5,3,'255746805382','255746805382','2021-09-26 19:53:55','13','8','failed','123','Patient','2021-10-04 00:18:36','2021-10-04 00:18:36'),(6,1,'255746805385','255746805385','2021-09-26 19:53:55','0754323131','8','failed','123','Patient','2021-10-04 00:19:36','2021-10-04 00:19:36');
/*!40000 ALTER TABLE `calls` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cdrs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdrs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `callingDate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mssidn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lang` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selectedAudio` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentStatus` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uniqueId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calledDr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newCustomer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serviceRating` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hangupCause` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callingStage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callOutCome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cdrs` WRITE;
/*!40000 ALTER TABLE `cdrs` DISABLE KEYS */;
INSERT INTO `cdrs` VALUES (1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-20 03:24:19','2022-01-20 03:24:19'),(2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-20 03:25:21','2022-01-20 03:25:21'),(3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-20 03:25:53','2022-01-20 03:25:53');
/*!40000 ALTER TABLE `cdrs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `chief_complaints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chief_complaints` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `chief_complaints` WRITE;
/*!40000 ALTER TABLE `chief_complaints` DISABLE KEYS */;
/*!40000 ALTER TABLE `chief_complaints` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `districts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `region_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `districts_region_id_foreign` (`region_id`),
  CONSTRAINT `districts_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` VALUES (1,'Meru',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(2,'Arusha Urban',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(3,'Arusha Rural',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(4,'Karatu',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(5,'Longido',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(6,'Monduli',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(7,'Ngorongoro',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(8,'Ilala',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(9,'Kinondoni',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(10,'Temeke',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(11,'Ubungo',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(12,'Kigamboni',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(13,'Bahi',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(14,'Chamwino',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(15,'Chemba',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(16,'Dodoma',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(17,'Kondoa',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(18,'Kongwa',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(19,'Mpwapwa',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(20,'Bukombe',4,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(21,'Chato',4,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(22,'Geita Urban',4,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(23,'Geita Rural',4,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(24,'Mbongwe',4,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(25,'Nyang\'hwale',4,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(26,'Iringa Rural',5,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(27,'Iringa Urban',5,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(28,'Kilolo',5,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(29,'Mafinga',5,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(30,'Mufindi',5,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(31,'Biharamulo',6,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(32,'Bukoba',6,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(33,'Karagwe',6,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(34,'Kyerwa',6,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(35,'Missenyi',6,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(36,'Muleba',6,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(37,'Ngara',6,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(38,'Micheweni',19,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(39,'Wete',19,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(40,'Kaskazini A',29,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(41,'Kaskazini B',29,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(42,'Mlele',7,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(43,'Mpanda',7,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(44,'Buhigwe',8,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(45,'Kakonko',8,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(46,'Kasulu',8,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(47,'Kasulu',8,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(48,'Kibondo',8,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(49,'Kigoma',8,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(50,'Kigoma-Ujiji',8,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(51,'Uvinza',8,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(52,'Hai',9,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(53,'Moshi Rural',9,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(54,'Moshi Urban',9,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(55,'Mwanga',9,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(56,'Rombo',9,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(57,'Same',9,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(58,'Siha',9,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(59,'Chake Chake',20,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(60,'Mkoani',20,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(61,'Kati',30,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(62,'Kusini',30,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(63,'Kilwa',10,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(64,'Lindi Rural',10,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(65,'Lindi Urban',10,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(66,'Liwale',10,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(67,'Nachingwea',10,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(68,'Ruangwa',10,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(69,'Babati Urban',11,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(70,'Babati Rural',11,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(71,'Hanang',11,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(72,'Kiteto',11,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(73,'Mbulu',11,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(74,'Simanjiro',11,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(75,'Bunda',12,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(76,'Butiama',12,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(77,'Musoma Rural',12,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(78,'Musoma Urban',12,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(79,'Rorya',12,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(80,'Serengeti',12,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(81,'Tarime',12,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(82,'Chunya',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(83,'Ileje',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(84,'Kyela',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(85,'Mbarali',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(86,'Mbeya Urban',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(87,'Mbeya Rural',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(88,'Mbozi',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(89,'Momba',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(90,'Rungwe',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(91,'Tunduma',13,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(92,'Magharibi',14,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(93,'Mjini',14,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(94,'Gairo',15,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(95,'Kilombero',15,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(96,'Kilosa',15,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(97,'Morogoro Rural',15,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(98,'Morogoro Urban',15,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(99,'Mvomero',15,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(100,'Ulanga',15,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(101,'Masasi Rural',16,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(102,'Masasi Urban',16,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(103,'Mtwara',16,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(104,'Mtwara',16,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(105,'Nanyumbu',16,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(106,'Newala',16,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(107,'Tandahimba',16,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(108,'Ilemela',17,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(109,'Kwimba',17,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(110,'Magu',17,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(111,'Misungwi',17,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(112,'Nyamagana',17,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(113,'Sengerema',17,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(114,'Ukerewe',17,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(115,'Ludewa',18,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(116,'Makambako',18,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(117,'Makete',18,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(118,'Njombe Rural',18,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(119,'Njombe Urban',18,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(120,'Wanging\'ombe',18,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(121,'Bagamoyo',21,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(122,'Kibaha Rural',21,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(123,'Kibaha Urban',21,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(124,'Kisarawe',21,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(125,'Mafia',21,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(126,'Mkuranga',21,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(127,'Rufiji',21,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(128,'Kalambo',22,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(129,'Nkasi',22,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(130,'Sumbawanga Rural',22,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(131,'Sumbawanga Urban',22,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(132,'Mbinga',23,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(133,'Songea Rural',23,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(134,'Songea Urban',23,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(135,'Tunduru',23,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(136,'Namtumbo',23,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(137,'Nyasa',23,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(138,'Kahama Urban',24,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(139,'Kahama Rural',24,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(140,'Kishapu',24,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(141,'Shinyanga Rural',24,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(142,'Shinyanga Urban',24,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(143,'Bariadi',25,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(144,'Busega',25,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(145,'Itilima',25,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(146,'Maswa',25,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(147,'Meatu',25,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(148,'Ikungi',26,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(149,'Iramba',26,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(150,'Manyoni',26,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(151,'Mkalama',26,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(152,'Singida Rural',26,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(153,'Singida Urban',26,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(154,'Igunga',27,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(155,'Kaliua',27,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(156,'Nzega',27,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(157,'Sikonge',27,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(158,'Tabora',27,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(159,'Urambo',27,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(160,'Uyui',27,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(161,'Handeni Rural',28,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(162,'Handeni Urban',28,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(163,'Kilindi',28,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(164,'Korogwe Urban',28,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(165,'Korogwe Rural',28,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(166,'Lushoto',28,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(167,'Muheza',28,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(168,'Mkinga',28,'2021-10-02 08:31:56','2021-10-02 08:31:56',NULL,NULL),(169,'Pangani',28,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(170,'Tanga Urban',28,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL);
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nationId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medicalSchool` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `health_facility` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `health_facility_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `section` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currentemployer_otherinfo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medicalRegisterNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `box` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cellphone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `effective_communication` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_care` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medical_ethics` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telehealth` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `region_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user.jpg',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES (1,'John','Michael',NULL,NULL,'0746805383',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,'user.jpg','2021-10-02 08:31:57','2021-10-02 08:31:57');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `emaillogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emaillogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `to` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `emaillogs` WRITE;
/*!40000 ALTER TABLE `emaillogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `emaillogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `log_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `log_activities` WRITE;
/*!40000 ALTER TABLE `log_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_activities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (73,'2014_10_12_000000_create_users_table',1),(74,'2014_10_12_100000_create_password_resets_table',1),(75,'2017_07_12_145959_create_permission_tables',1),(77,'2020_03_25_070340_create_log_activities_table',1),(78,'2020_03_27_072957_create_doctors_table',1),(79,'2020_03_27_121938_create_prescriptions_table',1),(80,'2020_03_28_053549_create_symptoms_table',1),(81,'2020_03_29_120440_create_location_tables',1),(82,'2020_04_10_211014_create_schedules_table',1),(83,'2020_04_16_123517_create_representatives_table',1),(84,'2020_05_01_114017_create_calls_table',1),(85,'2020_05_16_152923_create_smslogs_table',1),(86,'2020_05_16_153403_create_emaillogs_table',1),(87,'2020_05_20_163916_create_location_reports_view',1),(88,'2020_06_04_171542_create_chief_complaints_table',1),(89,'2020_06_04_172149_create_prescription_chiefcomplaints_table',1),(90,'2020_06_10_044103_create_prescription_symptoms_table',1),(92,'2020_03_24_052040_create_patients_table',2),(93,'2022_01_20_060853_create_cdrs_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pat_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otherphone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doctor_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'Julius','AC-000001','18','John','juliusjohn46@gmail.com','Male','0746805383',NULL,'2','9','1',NULL,'2022-01-16 06:32:21','2022-01-16 06:32:21');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'users_manage','web','2021-10-02 08:31:55','2021-10-02 08:31:55'),(2,'doctor_manage','web','2021-10-02 08:31:55','2021-10-02 08:31:55');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prescription_chiefcomplaints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription_chiefcomplaints` (
  `prescription_id` int(10) unsigned NOT NULL,
  `chief_complaint_id` int(10) unsigned NOT NULL,
  KEY `prescription_chiefcomplaints_prescription_id_foreign` (`prescription_id`),
  KEY `prescription_chiefcomplaints_chief_complaint_id_foreign` (`chief_complaint_id`),
  CONSTRAINT `prescription_chiefcomplaints_chief_complaint_id_foreign` FOREIGN KEY (`chief_complaint_id`) REFERENCES `chief_complaints` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prescription_chiefcomplaints_prescription_id_foreign` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prescription_chiefcomplaints` WRITE;
/*!40000 ALTER TABLE `prescription_chiefcomplaints` DISABLE KEYS */;
/*!40000 ALTER TABLE `prescription_chiefcomplaints` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prescription_symptoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription_symptoms` (
  `prescription_id` int(10) unsigned NOT NULL,
  `symptom_id` int(10) unsigned NOT NULL,
  KEY `prescription_symptoms_prescription_id_foreign` (`prescription_id`),
  KEY `prescription_symptoms_symptom_id_foreign` (`symptom_id`),
  CONSTRAINT `prescription_symptoms_prescription_id_foreign` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prescription_symptoms_symptom_id_foreign` FOREIGN KEY (`symptom_id`) REFERENCES `symptoms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prescription_symptoms` WRITE;
/*!40000 ALTER TABLE `prescription_symptoms` DISABLE KEYS */;
/*!40000 ALTER TABLE `prescription_symptoms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cheif_complaint` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callers` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dangersign` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hist_pres_ill` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prov_diagnos` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surgeries` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sugreries_reaction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastdatemens` date DEFAULT NULL,
  `number_pregnance` int(11) DEFAULT NULL,
  `number_live_birth` int(11) DEFAULT NULL,
  `preg_complication` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `counc_advice` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_plans` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conclusion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medication_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medication_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dd` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prescriptions` WRITE;
/*!40000 ALTER TABLE `prescriptions` DISABLE KEYS */;
INSERT INTO `prescriptions` VALUES (1,'1','1',NULL,'Not Set','Not Set','location of pain is in Head,',NULL,'No',NULL,NULL,NULL,NULL,NULL,'Yes to Muhimbili Hospital',NULL,NULL,'Select your Call outcome','Not Set',NULL,NULL,'2022-01-16 06:32:51','2022-01-16 06:32:51'),(2,'1','1',NULL,'Not Set','loss of consciousness',NULL,NULL,'No',NULL,NULL,NULL,NULL,NULL,'Yes to Muhimbili Hospital',NULL,NULL,'Select your Call outcome','Not Set',NULL,NULL,'2022-01-16 09:36:05','2022-01-16 09:36:05');
/*!40000 ALTER TABLE `prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zone_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `regions_zone_id_foreign` (`zone_id`),
  CONSTRAINT `regions_zone_id_foreign` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` VALUES (1,'Arusha','23000',4,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(2,'Dar es Salaam','11000',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(3,'Dodoma','41000',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(4,'Geita','30000',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(5,'Iringa','51000',5,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(6,'Kagera','35000',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(7,'Katavi','50000',5,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(8,'Kigoma','47000',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(9,'Kilimanjaro','25000',4,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(10,'Lindi','65000',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(11,'Manyara','27000',4,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(12,'Mara','31000',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(13,'Mbeya','53000',5,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(14,'Mjini Magharibi','71000',6,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(15,'Morogoro','67000',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(16,'Mtwara','63000',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(17,'Mwanza','33000',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(18,'Njombe','59000',5,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(19,'Pemba North','75000',6,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(20,'Pemba South','74000',6,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(21,'Pwani','61000',2,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(22,'Rukwa','55000',5,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(23,'Ruvuma','57000',5,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(24,'Shinyanga','37000',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(25,'Simiyu','39000',3,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(26,'Singida','43000',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(27,'Tabora','45000',1,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(28,'Tanga','21000',4,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(29,'Unguja North','73000',6,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(30,'Unguja South','72000',6,'2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL);
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `representatives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `representatives` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `representatives` WRITE;
/*!40000 ALTER TABLE `representatives` DISABLE KEYS */;
/*!40000 ALTER TABLE `representatives` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'administrator','web','2021-10-02 08:31:55','2021-10-02 08:31:55');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,'2021-10-02','11:31:57','12:31:57',1,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL,NULL);
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `smslogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smslogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `to` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `smslogs` WRITE;
/*!40000 ALTER TABLE `smslogs` DISABLE KEYS */;
INSERT INTO `smslogs` VALUES (1,'255746805383','Your Afyacall Number is AC000001','201','2022-01-16 06:33:14','2022-01-16 06:33:14'),(2,'255746805383','Your Afyacall Number is AC000001','201','2022-01-16 09:36:26','2022-01-16 09:36:26');
/*!40000 ALTER TABLE `smslogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `streets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ward_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `streets_ward_id_foreign` (`ward_id`),
  CONSTRAINT `streets_ward_id_foreign` FOREIGN KEY (`ward_id`) REFERENCES `wards` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `streets` WRITE;
/*!40000 ALTER TABLE `streets` DISABLE KEYS */;
INSERT INTO `streets` VALUES (1,'Suna',1,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(2,'Makuti A',1,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(3,'Makuti B',1,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(4,'Dossi',1,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(5,'Idrisa',1,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(6,'Idrisa',2,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(7,'Makumbusho',2,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(8,'Mtambani',2,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(9,'Mwinyimkuu',2,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(10,'Mpakani',3,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(11,'Mikoroshini',3,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(12,'Makanya',3,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(13,'Vigaeni',3,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(14,'Mtogole',4,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(15,'Kwa Tumbo',4,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(16,'Pakacha',4,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(17,'Sokoni',4,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(18,'Mkunduge',4,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(19,'Muhaltani',4,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(20,'Makumbusho',5,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(21,'Minazini',5,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(22,'Mchangani',5,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(23,'Kisiwani',5,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(24,'Mbuyuni',5,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(25,'Singano',5,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(26,'Kambangwa',6,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(27,'Msisiri B',6,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(28,'Msisiri A',6,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(29,'Bwawani',6,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(30,'Mwinjuma',6,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(31,'Kwa Kopa',6,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(32,'Msolomi',6,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(33,'Hananasif',7,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(34,'Kisutu',7,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(35,'Mkunguni A',7,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(36,'Mkunguni B',7,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(37,'Kawawa',7,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(38,'Kumbukumbu',8,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(39,'Kinondoni Mjini',8,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(40,'Kinondoni Shamba',8,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(41,'Ada Estate',8,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(42,'Oysterbay',9,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(43,'Masaki',9,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(44,'Mikoroshoni',9,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(45,'Bonde la Mpunga',9,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(46,'Makangira',9,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(47,'Mikocheni A',10,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(48,'Mikocheni B',10,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(49,'Regent Estate',10,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(50,'Ally H. Mwinyi',10,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(51,'TPDC',10,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(52,'Darajani',10,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(53,'Kijitonyama',11,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(54,'Alimaua A',11,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(55,'Alimaua B',11,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(56,'Mpakani A',11,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(57,'Mpakani B',11,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(58,'Bwawani',11,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(59,'Mwenge',11,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(60,'Nzasa',11,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(61,'Kigogo Kati',12,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(62,'Kigogo Mkwajuni',12,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(63,'Kigogo Mbuyuni',12,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(64,'Mzimuni',13,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(65,'Ukwamani',13,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(66,'Mbezi Beach A',13,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(67,'Mbezi Beach B',13,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(68,'Pwani',14,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(69,'Kilongawima',14,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(70,'Mtongani',14,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(71,'Tegeta',14,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(72,'Ununio',14,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(73,'Kondo',14,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(74,'Boko',15,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(75,'Bunju A',15,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(76,'Kilungule',15,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(77,'Busihaya',15,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(78,'Dovya',15,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(79,'Mkoani',15,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(80,'Maputo',16,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(81,'Mbweni',16,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(82,'Teta',16,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(83,'Malindi Estate',16,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(84,'Mpiji Mbweni',16,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(85,'Jogoo',17,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(86,'Ndumbwi',17,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(87,'Mbezi Mtoni',17,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(88,'Mbezi Kati',17,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(89,'Mbezi Juu',17,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(90,'Changanyikeni',18,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(91,'Mbuyuni',18,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(92,'Mlalakuwa',18,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(93,'Makongo',18,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(94,'Wazo',19,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(95,'Salasala',19,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(96,'Kilimahewa',19,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(97,'Madale',19,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(98,'Mivumoni',19,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(99,'Kisanga',19,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(100,'Kilimahewa Juu',19,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(101,'Nakasangwe',19,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(102,'Bunju B',20,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(103,'Mabwe Pande',20,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(104,'Mjimpya',20,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(105,'Kihonzile',20,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(106,'Mbopo',20,'2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL);
/*!40000 ALTER TABLE `streets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `symptoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symptoms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `symptoms_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symptoms_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `symptoms` WRITE;
/*!40000 ALTER TABLE `symptoms` DISABLE KEYS */;
/*!40000 ALTER TABLE `symptoms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `total_doctors_per_district`;
/*!50001 DROP VIEW IF EXISTS `total_doctors_per_district`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `total_doctors_per_district` (
  `region_id` tinyint NOT NULL,
  `region_name` tinyint NOT NULL,
  `district_id` tinyint NOT NULL,
  `district_name` tinyint NOT NULL,
  `total_doctors` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `total_doctors_per_region`;
/*!50001 DROP VIEW IF EXISTS `total_doctors_per_region`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `total_doctors_per_region` (
  `region_id` tinyint NOT NULL,
  `region_name` tinyint NOT NULL,
  `total_doctors` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `total_patients_per_district`;
/*!50001 DROP VIEW IF EXISTS `total_patients_per_district`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `total_patients_per_district` (
  `region_id` tinyint NOT NULL,
  `region_name` tinyint NOT NULL,
  `district_id` tinyint NOT NULL,
  `district_name` tinyint NOT NULL,
  `total_patients` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `total_patients_per_region`;
/*!50001 DROP VIEW IF EXISTS `total_patients_per_region`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `total_patients_per_region` (
  `region_id` tinyint NOT NULL,
  `region_name` tinyint NOT NULL,
  `total_patients` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','calls@afyacall.com','$2y$10$369h9SN2wF///CGTZQoFYutS0ZMkegKpRP02zeyIzqlVa6g9Eh3bq',1,NULL,'0746805383',NULL,'2021-10-02 08:31:55','2021-10-02 08:31:55');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `wards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `postcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wards_district_id_foreign` (`district_id`),
  CONSTRAINT `wards_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `wards` WRITE;
/*!40000 ALTER TABLE `wards` DISABLE KEYS */;
INSERT INTO `wards` VALUES (1,'Magomeni',9,'14101','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(2,'Mzimuni',9,'14102','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(3,'Ndugumbi',9,'14104','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(4,'Tandale',9,'14106','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(5,'Makumbusho',9,'14107','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(6,'Mwananyamala',9,'14108','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(7,'Hananasif',9,'14109','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(8,'Kinondoni',9,'14110','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(9,'Msasani',9,'14111','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(10,'Mikocheni',9,'14112','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(11,'Kijitonyama',9,'14113','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(12,'Kigogo',9,'14118','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(13,'Kawe',9,'14121','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(14,'Kunduchi',9,'14122','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(15,'Bunju',9,'14125','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(16,'Mbweni',9,'14126','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(17,'Mbezi Juu',9,'14128','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(18,'Makongo',9,'14129','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(19,'Wazo',9,'14130','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL),(20,'Mabwepande',9,'14134','2021-10-02 08:31:57','2021-10-02 08:31:57',NULL,NULL);
/*!40000 ALTER TABLE `wards` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `zones` WRITE;
/*!40000 ALTER TABLE `zones` DISABLE KEYS */;
INSERT INTO `zones` VALUES (1,'Central','2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(2,'Coastal','2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(3,'Lake','2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(4,'Northern','2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(5,'Southern Highlands','2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL),(6,'Zanzibar','2021-10-02 08:31:55','2021-10-02 08:31:55',NULL,NULL);
/*!40000 ALTER TABLE `zones` ENABLE KEYS */;
UNLOCK TABLES;
/*!50001 DROP TABLE IF EXISTS `total_doctors_per_district`*/;
/*!50001 DROP VIEW IF EXISTS `total_doctors_per_district`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_doctors_per_district` AS select `r`.`id` AS `region_id`,`r`.`name` AS `region_name`,`di`.`id` AS `district_id`,`di`.`name` AS `district_name`,count(`d`.`id`) AS `total_doctors` from ((`districts` `di` left join `regions` `r` on(`di`.`region_id` = `r`.`id`)) left join `doctors` `d` on(`di`.`id` = `d`.`district_id`)) group by `r`.`id`,`r`.`name`,`di`.`id`,`di`.`name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP TABLE IF EXISTS `total_doctors_per_region`*/;
/*!50001 DROP VIEW IF EXISTS `total_doctors_per_region`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_doctors_per_region` AS select `r`.`id` AS `region_id`,`r`.`name` AS `region_name`,count(`d`.`id`) AS `total_doctors` from (`regions` `r` left join `doctors` `d` on(`r`.`id` = `d`.`region_id`)) group by `r`.`id`,`r`.`name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP TABLE IF EXISTS `total_patients_per_district`*/;
/*!50001 DROP VIEW IF EXISTS `total_patients_per_district`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_patients_per_district` AS select `r`.`id` AS `region_id`,`r`.`name` AS `region_name`,`di`.`id` AS `district_id`,`di`.`name` AS `district_name`,count(`p`.`id`) AS `total_patients` from ((`districts` `di` left join `regions` `r` on(`di`.`region_id` = `r`.`id`)) left join `patients` `p` on(`di`.`id` = `p`.`district_id`)) group by `r`.`id`,`r`.`name`,`di`.`id`,`di`.`name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP TABLE IF EXISTS `total_patients_per_region`*/;
/*!50001 DROP VIEW IF EXISTS `total_patients_per_region`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_patients_per_region` AS select `r`.`id` AS `region_id`,`r`.`name` AS `region_name`,count(`p`.`id`) AS `total_patients` from (`regions` `r` left join `patients` `p` on(`r`.`id` = `p`.`region_id`)) group by `r`.`id`,`r`.`name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

